import React from 'react';
import { Plus, Minus, ArrowRight, Play, Pause, RotateCcw, SkipForward, Check } from 'lucide-react';

export default function App() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Tashmeera Project</h1>
      <p>المشروع جاهز للتشغيل ✨</p>
    </div>
  );
}
